package abstract_factory.java.Modelo;

public class SofaModerno implements Sofa {

	public void deitar() {
		System.out.println("Deitar no sofá!!!");
	}

}
