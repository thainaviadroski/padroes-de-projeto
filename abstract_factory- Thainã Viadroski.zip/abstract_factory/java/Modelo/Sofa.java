package abstract_factory.java.Modelo;

public interface Sofa {

	public void deitar();

}
