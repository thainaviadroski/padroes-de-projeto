package abstract_factory.java.Modelo;

public class SofaVitoriano implements Sofa{

	public void deitar() {
		System.out.println("Deitar no sofá!!!");
	}
}


