package abstract_factory.java.Modelo;

public interface Cadeira {

    public void sentar();
    
}
