package abstract_factory.java.Modelo;

public class MesaDeCentroArtDeco implements MesaDeCentro {
	@Override
	public void colocarDecoracao() {
		System.out.println("Mesa de centro Art Deco!!!");
	}
}
