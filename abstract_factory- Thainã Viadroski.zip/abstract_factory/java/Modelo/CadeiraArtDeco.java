package abstract_factory.java.Modelo;

public class CadeiraArtDeco implements  Cadeira{

	public void sentar() {
		System.out.println("Vou sentar nessa coisa!!");
	}
}
