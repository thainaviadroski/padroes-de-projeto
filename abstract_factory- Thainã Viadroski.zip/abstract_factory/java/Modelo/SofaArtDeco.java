package abstract_factory.java.Modelo;

public class SofaArtDeco implements Sofa{

	public void deitar() {
		System.out.println("Deitado no sofá!!");
	}
}
