package factory_method.java.depois_do_padrao.modelo;

public class Dutoviario extends Transporte{

	@Override
	public void entregar() {
		System.out.println("Entrega com transporte Dutoviário.");
	}
}
